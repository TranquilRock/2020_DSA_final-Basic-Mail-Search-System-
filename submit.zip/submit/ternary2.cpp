#include <cstdlib> 
#include <vector>
#include <iostream>
#include <cstring>
using namespace std;
#define IDMAX 1300
// A node of ternary search tree
struct mail{
    string from,to;
    //string subject;
    int id,length;
    unsigned long long date;
    bool currently_valid;
    //ex:   19 May 2011 at 16:50
    //   -> 201105191650
    //set<string> content;
    mail(){};
};
/*unsigned char precal[8]={
    1,1<<1,1<<2,1<<3,1<<4,1<<5,1<<6,1<<7;
}*/
void bset_insert(unsigned char *a,int id){
    a[id/8]|=1<<(id%8);
}
void bset_erase(unsigned char *a,int id){
    a[id/8]&=~(1<<(id%8));
}

struct Node 
{ 
    char data; 
  
    // True if this character is last character of one of the words 
    unsigned char *bit;
    bool isend;
    struct Node *left, *eq, *right;
    Node(char x):data(x){
        left=eq=right=NULL;
        isend=0;
    };
}; 
  
// A utility function to create a new ternary search tree node 
// struct Node* newNode(char data) 
// { 
//     struct Node* temp = new node()//(struct Node*) malloc(sizeof( struct Node )); 
//     temp->data = data; 
//     temp->left = temp->eq = temp->right = NULL; 
//     return temp; 
// } 
// Function to insert a new word in a Ternary Search Tree 
void TST_insert(struct Node** root,const char *word ,mail * M) 
{   
    while(*word){
        //assert((!isalpha(*word))||islower(*word));
        //if(!isalnum(*word))cout <<"WTF" <<*word <<"WTF";
        if ((*root)==NULL) {(*root) = new Node(*word);}
        if ((*word) < (*root)->data) 
            root=&(*root)->left; 

        else if ((*word) > (*root)->data) 
            root=&(*root)->right; 
      
        else
        { 
            if (*(word+1)) 
                (root)=&((*root)->eq);
            else{   
                //cout <<"fuckme\n";
                if((*root)->isend){
                    bset_insert((*root)->bit,M->id);
                }
                else{
                    (*root)->isend=1;
                    (*root)->bit=new unsigned char[IDMAX];
                    memset((*root)->bit,0,IDMAX);
                    bset_insert((*root)->bit,M->id);
                }
                //(*root)->TST_set.insert(M); 
            }
            word++;
        } 
    }
    
} 
Node* searchTST(struct Node *root, const char *word) 
{ 
    if(*word==0)return NULL;
    while(*word){

        if (!root) 
            return NULL;
        if (*word < (root)->data) 
            root=root->left;

        else if (*word > (root)->data) 
            root=root->right;   

        else
        { 
            if (*(word+1) == '\0') 
                return root; 
            else word++,root=root->eq; 
        } 
    }
    return root;
} 
// // A recursive function to traverse Ternary Search Tree 
void traverseTSTUtil(struct Node* root, char* buffer, int depth) 
{ 
    if (root) 
    { 
        // First traverse the left subtree 
        traverseTSTUtil(root->left, buffer, depth); 
  
        // Store the character of this node 
        buffer[depth] = root->data; 
        if (root->isend) 
        { 
            buffer[depth+1] = '\0'; 
            cout <<buffer;
            cout <<" "<<*root->bit;
            cout <<endl;
        } 
  
        // Traverse the subtree using equal pointer (middle subtree) 
        traverseTSTUtil(root->eq, buffer, depth + 1); 
  
        // Finally Traverse the right subtree 
        traverseTSTUtil(root->right, buffer, depth); 
    } 
} 
  
// // The main function to traverse a Ternary Search Tree. 
// // It mainly uses traverseTSTUtil() 
void traverseTST(struct Node* root) 
{ 
    char buffer[10000]; 
    cout <<"\nTTTTT\n";
    traverseTSTUtil(root, buffer, 0); 
} 
  
// // Function to search a given word in TST 
