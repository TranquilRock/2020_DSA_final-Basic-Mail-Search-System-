#include<unordered_map>
#include<vector>
#include<string>
#include<stack>
using namespace std;
unordered_map <string,int> prec;
void set_precedence() {
	prec["("] = prec[")"] = 0;
	prec["!"] = 1;
	prec["&"] = 6;
	prec["|"] = 8;
}
void topost2(const string &in, vector<string>& post){
	stack<string> op;
	for(int i=0;i<in.length();i++){
		if(in[i]==' ' || in[i]=='\n')continue;
		if(isalnum(in[i])){
			int j=i+1;
			while (isalnum(in[j]) )j++;
			post.push_back(string(in.begin()+i,in.begin()+j));
			i=j-1;
		}
		else if(in[i]=='('){
			op.push("(");
			continue;
		}
		else if(in[i]==')'){
			while(op.top()!="("){
				post.push_back(op.top());
				op.pop();
			}
			op.pop();
		}
		else {
			string temp;
			temp.push_back(in[i]);
			while (!op.empty() && op.top()!="(" &&prec[op.top()] <= prec[temp] && prec[temp]>1){
				post.push_back(op.top());
				op.pop();
			}
			op.push(temp);
		}
	}
	while(!op.empty()){
		post.push_back(op.top());
		op.pop();
	}
	return ;
}

