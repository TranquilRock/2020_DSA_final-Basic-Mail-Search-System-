#include<iostream>
#include<climits>
#include<algorithm>
#include<vector>
#include<set>
#include<map>
#include<string>
#include<fstream>
#include<unistd.h>
#include<sys/wait.h>
#include<cassert>
#include<sstream>
#include<cstring>
#include "ternary2.cpp"
#include "expression.cpp"
using namespace std;
int idrangeL=IDMAX,idrangeR=0;
struct length_compare {
    bool operator() (const mail* a, const mail* b) const {
        if(a ->length == b->length)return a->id < b->id;
        return a->length > b->length;
    }
};
unsigned char allid[IDMAX]={0};
unsigned char zero[IDMAX]={0};
int previousqID=-1;
int ppipe[1000000][2];
int cpipe[1000000][2];
int child=0;
//unordered_map<int,mail*> container;
mail* container[IDMAX*8];
unsigned long long convert_date(const char *);

Node *TST_root=NULL;
//map<string,set<mail*,id_compare> >alter;

set<mail*,length_compare> lengthset;

void TOLOW(string &s){
	for(int i=0;i<s.length();i++){
		if(s[i]<='Z' && s[i]>='A')s[i]+=32;
	}
}
void TOLOW(char *s){
	while(*s){
		if(*s<='Z' && *s>='A')*s+=32;
		s++;
	}
}
//map <int ,string> path_unique;

int add(struct mail *M){
	char path[32];
	//string path;
	cin >> path;
	// cout <<"WTF"<<path <<"asd"<<'\n' <<"fu";
	fstream f;
	f.open(path,fstream::in);
	//cout << f.is_open();
	if(!f.is_open())return 0;//read file fail
	char trash[64];

	M->length=0;

	f >> trash;//from
	f >> M->from;
	TOLOW(M->from);
	//M->length+=M->from.length();
	// cout <<"sender "<< M->from << endl;
	
	f >> trash;//date
	f.getline(trash,64);
	
	//M->length+=strlen(trash)-5;
	
	M->date=convert_date(trash);
	//convert date to number
	//cout<<"date " << M->date <<' ';//<< endl;

	f >>trash;//ID
	f >>M->id;
	/*if(path_unique.find(M->id)!=path_unique.end()){
		assert(path_unique[M->id]==path);
	}
	else path_unique.insert(make_pair(M->id,path));*/
	//for(int i=M->id;i!=0;i/=10)M->length++;
	// cout <<"id "<< M->id << endl;
	mail* z=container[M->id];
	if(z!=NULL){
		if (z->currently_valid)return 0;
		else {
			return 2;
		};
	}
	f >>trash;
	f.ignore();
	string splitsb;
	getline(f,splitsb);
	TOLOW(splitsb);
	//cout <<"subject "<< M->subject<<endl;

	f >>trash;//To
	f >>M->to;
	TOLOW(M->to);
	//M->length+=M->to.length();
 	// cout << M->to << " to\n";

	
	string temp;
	//TST_insert(&TST_root,M->from.c_str(),M);
	//TST_insert(&TST_root,M->to.c_str(),M);

	//split subject
	//strncpy(splitsb,M->subject.c_str(),128);

	for(int i=0;i<splitsb.length();i++){
		int j=i;
		while(isalnum(splitsb[j]))++j;
		if(j==i)continue;
		splitsb[j]='\0';

		//alter[splitsb].insert(M);
		TST_insert(&TST_root,splitsb.c_str()+i,M);

		//gen << splitsb.c_str()+i <<endl;
		//M->length+=j-i;
		i=j;
	}
	//TST_insert(&TST_root,M->subject.c_str(),M);
	f>>trash;
	while(getline(f,temp)){
		int i=0,j=0;
		while(j<temp.length()){
			while(isalnum(temp[j]))j++;
			if(i!=j){
				//this is segment of content
				string inserting_element=string(temp.begin()+i,temp.begin()+j);
				TOLOW(inserting_element);
				//cout << "inserted " << inserting_element << endl;
				// M->content.insert(inserting_element);
				//alter[inserting_element].insert(M);
				TST_insert(&TST_root,inserting_element.c_str(),M);
				//gen << inserting_element.c_str() <<endl;
				//assert(searchTST(TST_root,inserting_element.c_str())!=NULL);
				//assert(searchTST(TST_root,inserting_element.c_str())->TST_set.find(M)!=searchTST(TST_root,inserting_element.c_str())->TST_set.end());
				M->length+=inserting_element.length();
			}
			i=++j;

		}
	}
	//f >>
	f.close();
	return 1;
}
void uni(unsigned char *a,unsigned char *b){
	a+=idrangeL;
	b+=idrangeL;
	for(int i=idrangeL;i<=idrangeR;i++){
		//c[i]=a[i]|b[i];
		*(b++)|=*(a++);
	}
}
void intersec(unsigned char *a,unsigned char *b){
	a+=idrangeL;
	b+=idrangeL;
	for(int i=idrangeL;i<=idrangeR;i++){
		//c[i]=a[i]&b[i];
		*(b++)&=*(a++);
	}
}
void diff(unsigned char *a,unsigned char *b){
	a+=idrangeL;
	b+=idrangeL;
	for(int i=idrangeL;i<=idrangeR;i++){
		//b[i]=a[i]&(~b[i]);
		*(b)=*(a++)&(~*(b));
		b++;
	}
}
unsigned char* evaluate(vector<string> &post){
	stack< unsigned char* >num;
	/*for(auto k:post)cout << k <<" ";
	cout << "***post";*/
	for(string &seg:post){
		//assert(seg!="");
		if(seg=="")continue;
		if(isalnum(seg[0])){
			Node* ss=searchTST(TST_root,seg.c_str());
			num.push(new unsigned char[IDMAX]);
			if(ss!=NULL && ss->isend){
				//cout << "??"<<seg.c_str()<<"??";
				memcpy(num.top(),ss->bit,IDMAX);
			}
			else memset(num.top(),0,IDMAX);
			// auto ss=alter.find(seg);
			// if(ss==alter.end())num.push(set<mail*,id_compare>());
			// else num.push(ss->second);
		}
		else {
			
			//assert(prec.find(seg)!=prec.end());

			if(seg=="!"){
				//set_difference(allid.begin(),allid.end(),
				//num.top().begin(),num.top().end(),std::inserter(temp,temp.begin()));
				diff(allid,num.top());
				//else assert(seg=="u+");
			}
			else if(seg=="&" || seg=="|"){
				//assert(num.size()>=2);
				unsigned char* a=num.top();
				num.pop();
				/*for (auto k:a)cout <<k<<"* ";
				for (auto k:b)cout <<k<<"@ ";*/
				if(seg=="&"){
					// vector<mail*>wtf;
					// wtf.resize(100);
					intersec(a,num.top());
					//set_intersection(a.begin(),a.end(),b.begin(),b.end(),std::inserter(num.top(),num.top().begin()));
					//for (auto k:num.top())cout <<k->id<<"@* ";
				}
				else {
					uni(a,num.top());
					//exor(a,b,num.top());
					//set_union(a.begin(),a.end(),b.begin(),b.end(),std::inserter(num.top(),num.top().begin()));
				}
				delete[]a;
				}
			}

	}
	//assert(num.size()==1);
	if(num.empty()){
		unsigned char *x=new unsigned char[IDMAX];
		memset(x,0,IDMAX);
		return x;
	}
	return num.top();
}
char kkk[10];
void query(string &condition){
	int i=0;
	TOLOW(condition);
	/*cout << condition << endl;
	auto r=topost2(condition);
	for(auto &k:r)cout << k <<' ';
	cout <<"***post"<<endl;*/
	//cout <<condition<<"newline?";
	while(condition.back()=='\n' || condition.back()=='\r' ||condition.back()==' ')condition.pop_back();
	//cout <<condition<<"newline?";
	//cout <<"HI";
	string f,t;
	bool hasf=0,hast=0,hasL=0,hasR=0;
	unsigned long long L=0,R=ULLONG_MAX;
	vector<string> ex;
	//cout << endl;
	while( i < condition.length() ){
		if(condition[i]==' '||condition[i]=='\n'){i++;continue;}
		if (condition[i]=='-'){
			if(condition[i+1]=='f'){
				i+=3;//"
				hasf=1;
				while(condition[i]!='\"'){
					f.push_back(condition[i]);
					i++;
				}
			}
			else if (condition[i+1]=='t'){
				i+=3;//"
				hast=1;
				while(condition[i]!='\"'){
					t.push_back(condition[i]);
					i++;
				}
			}
			else if (condition[i+1]=='d'&&(condition[i+2]=='~' ||isdigit(condition[i+2]))){
					i+=2;

					if(isdigit(condition[i])){
						sscanf(condition.c_str()+i,"%llu",&L);
						hasL=1;
						while(condition[i]!='~')i++;
					}
					i++;
					if(isdigit(condition[i])){
							sscanf(condition.c_str()+i,"%llu",&R);
							hasR=1;
						}
			}
			
		}
		else{
			int j=i;
			while(condition[j]!=' ' && j<condition.length())j++;
			topost2(string(condition.begin()+i,condition.begin()+j),ex);
		}
		while(i<condition.length() && condition[i]!=' ')i++;
		i++;
	}
	//cout << ex.size()<<"**" ;
	//if(R!=ULLONG_MAX)cout <<"@@";
	/*cout <<"f" <<f <<endl;
	cout <<"t" <<t <<endl;
	cout <<"L" <<L <<endl;
	cout <<"R" <<R <<endl;*/
	/*for(auto&k:ex)cout << k <<" ";
	cout <<endl;
	cout <<"okhere1\n";*/
	/*cout << hasf << hast <<hasL <<hasR <<" has";
	cout <<" L "<< L <<" R "<<R<<" ";*/
	unsigned char* ret;
	if(ex.size()==0)ret=allid;
	else ret=evaluate(ex);
	int n=0;
	//cout <<int(*ret)<<"fff";
	//cout << "waiting" <<child <<condition<<endl;
	//char buffer[1024*64];
	stringstream ss;
	read(ppipe[child][0],kkk,10);
	close(ppipe[child][1]);
	close(ppipe[child][0]);
	//cout << "end waiting" <<child <<endl;
	for(int i=idrangeL;i<=	idrangeR;i++){
		unsigned char x=1;
		for(int j=0;j<8;j++,x<<=1){
			if(ret[i]&x){
				mail* k=container[i*8+j];
				//cout << i*8+j <<"ID";
				if(!k->currently_valid)continue;
				if(hasf && k->from!=f)continue;
				if(hast && k->to!=t)continue;
				if(hasL && k->date <L)continue;
				if(hasR && k->date>R)continue;
				if(n++)ss <<' ';
				ss << k->id;
			}
		}
	}
	if(n==0)ss<<"-";
	ss<<"\n";
	if(ex.size()!=0)delete[]ret;
	//cout << "done" <<child <<endl;
	//ss>>buffer;
	write(cpipe[child][1],ss.str().c_str(),ss.str().length());
	//cout << "done" <<child <<endl;
}
int fin=0;

void ww(){
	
	char buffer[1024*64];
	//cout << "WHYYY" << fin << "   " << child <<endl;
	while(fin!=child){
		write(ppipe[fin][1],"0",1);
		// cout <<"stuck ?" <<fin;
		int len=read(cpipe[fin][0],buffer,1024*64);
		// cout <<"NO"<<endl;
		buffer[len]=0;
		cout << buffer ;
		close(ppipe[fin][1]);
		close(ppipe[fin][0]);
		close(cpipe[fin][1]);
		close(cpipe[fin][0]);
		//write(ppipe[++fin][1],"0",1);
		++fin;
		if(fin==child)break;
	}
}
int main(){
	ios_base::sync_with_stdio(0);
	//cin.tie(0);
	string input;

	/*vector<mail*> m_vec;
	m_vec.reserve(10000);*/
	// cout <<"foog\n";
	//sleep(4);
	for(int i=0;i<IDMAX*8;i++)container[i]=NULL;
	int mailnum=0;
	set_precedence();
	int command=0;
	int ff=-1;
	
	while (cin >> input){
		//getline(cin,input);
		//cout << convert_date(input.c_str());
		//cout << ++command <<"  ";
		//if(++command==3279){cout <<"-\n";return 0;}
		if(input=="add"){
			//waitpid(previousqID,NULL,0);
			//wait();
			ww();
			mail* t=new mail();
			 // cout <<"goin";
			int state=add(t);
			 // cout <<"??";
			if(!state){
				delete(t);
				cout <<"-\n";
			}
			else if(state==2){
				mail* z=container[t->id];
				delete(t);
				z->currently_valid=1;
				cout <<++mailnum <<endl;
				lengthset.insert(z);
				bset_insert(allid,z->id);
			}
			else{
				container[t->id]=t;
				t->currently_valid=1;
				lengthset.insert(t);
				bset_insert(allid,t->id);
				idrangeR=max(t->id/8,idrangeR);
				idrangeL=min(t->id/8,idrangeL);
				cout <<++mailnum <<endl;
			}
		}
		
		else if (input== "remove"){
			//waitpid(previousqID,NULL,0);
			ww();
			//wait();
			int removing_id;
			cin >>removing_id;
			auto p=container[removing_id];
			//set iterator
			if(p==NULL || p->currently_valid==0){
				cout <<"-\n";
			}
			else{
				p->currently_valid=0;
				lengthset.erase(p);
				cout << --mailnum <<endl;
				bset_erase(allid,p->id);
			}
		}
		else if(input == "longest"){
			//waitpid(previousqID,NULL,0);
			ww();
			auto iter=lengthset.begin();
			if(iter!=lengthset.end()){
				//cout <<"l\n";
				cout << (*iter)->id <<" "<< (*iter)->length <<endl;
			}
			else cout <<"-\n";
		}
		else if (input=="query"){
			getline(cin,input);

			//cout <<"q";
			//cout << "q" <<input<<endl;
			//cout <<"**"<< (input.find('\n') ==string::npos)<<"hello"<<endl;
			previousqID=ff;
			pipe(ppipe[child]);
			pipe(cpipe[child]);
			ff=fork();
			assert(ff!=-1);
			if(ff==0){

				query(input);
				// for(int i=0;i<child;i++){
				// 	close(ppipe[i][0]);
				// 	close(ppipe[i][1]);
				// }
				close(cpipe[child][1]);
				close(cpipe[child][0]);
				return 0;
			}
			//cout << "parent" << input;
			child++;
		}
	}
	ww();
	wait(NULL);
	//traverseTST(TST_root);
	/*cout <<sizeabc<<endl;*/
}
unsigned long long convert_date(const char *a){
	
	unsigned long long t=0;
	int i=0;
	while(a[i]==' ')i++;
	t+=(a[i++]-'0')*10000;//day
	if(isdigit(a[i]))t*=10,t+=(a[i++]-'0')*10000;//day

	while(a[i]==' ')i++;
	// cout << t<<endl;
	unsigned long long month=0;
	if(a[i]=='J'){
		if(a[i+1]=='a')month=1;
		else if(a[i+2] =='n')month=6;
		else month=7;
	}
	else if (a[i]=='F')month=2;
	else if (a[i]=='M'){
		if(a[i+2]=='r')month=3;
		else month=5;
	}
	else if (a[i]=='A'){
		if(a[i+1]=='p')month=4;
		else month=8;
	}
	else if (a[i]=='S')month=9;
	else if (a[i]=='O')month=10;
	else if (a[i]=='N')month=11;
	else if (a[i]=='D')month=12;
	else cout <<"month error";
	t+=month*1000000;
	// cout << t<<endl;
	while( isalpha(a[i]) ||a[i]==' ' )i++;
	unsigned long long year;
	//cout << "?";
	sscanf(a+i,"%llu",&year);
	t+=year*100000000;
	//cout << t<<endl ;
	while( isdigit(a[i]) ||a[i]==' ' )i++;
	i+=3; // skip "at"
	t+=(a[i++]-'0')*1000;
	t+=(a[i++]-'0')*100;
	i++; //:
	t+=(a[i++]-'0')*10;
	t+=(a[i++]-'0');
	// cout << t<<endl;
	return t;
}